#haruki

import random
import time
print("足し算\n")
time.sleep(0.25)
c = int(input("回数を入力:"))

hit = 0
out = 0

while hit+out < c:
    r1 = random.randint(0,999)
    r2 = random.randint(0,999)
    time.sleep(0.1)
    q = int(input(str(r1)+"+"+str(r2)+"="))
    if r1+r2==q:
        print("正解")
        hit+=1
    else:
        print("間違い")
        out+=1

print("問題が終了しました")
time.sleep(0.5)
print("\n合計:"+str(hit+out)+" 回")
time.sleep(0.5)
print("正解:"+str(hit)+" 回")
time.sleep(0.5)
print("誤り:"+str(out)+" 回")
time.sleep(0.5)
print("正答率:"+str(hit*100/hit+out)+"\n")
time.sleep(0.5)
print("またしてね!")
time.sleep(1)